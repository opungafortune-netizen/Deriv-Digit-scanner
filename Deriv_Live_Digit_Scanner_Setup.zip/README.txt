DERIV LIVE DIGIT SCANNER
==========================

This is an analysis-only web app. It does not place trades and does not need
your Deriv password or trading API token.

EASIEST SETUP: GITHUB PAGES
---------------------------

1. Open https://github.com/ in Chrome and create/sign into a free account.
2. Create a NEW repository.
   - Give it a simple name such as: deriv-scanner
   - Choose Public.
   - Create the repository.
3. In the new repository, choose "Add file" -> "Upload files".
4. Upload index.html from this folder.
5. Commit the file.
6. Open Settings -> Pages.
7. Under "Build and deployment", choose:
      Source: Deploy from a branch
      Branch: main
      Folder: / (root)
8. Save.
9. GitHub will provide a Pages URL. Open that URL in Chrome.
10. Press SCAN / START.

IMPORTANT
---------
- The page must be opened using the HTTPS GitHub Pages URL, not as a file from
  the phone's Downloads folder.
- The scanner uses public market tick data. No Deriv login is required for the
  analysis.
- "Model score" is a heuristic score based on recent observed ticks. It is NOT
  a guaranteed probability of the next digit.
- Use a Deriv demo account while testing. The tool does not guarantee winning
  trades.

If GitHub is confusing, stop after step 2 and send me a screenshot. I can guide
you from exactly the screen you are on.
